# Enturma AI — Minecraft Forge 1.20.1

Mod social para Minecraft Java 1.20.1 e Forge 47.x. O Enturma permite conversar com mobs configurados, mantém um histórico limitado por criatura, envia contexto do mundo para o backend e executa somente ações explicitamente permitidas. Voz é opcional e depende do Simple Voice Chat.

## Interação

- Agache e clique com a mão vazia em uma criatura permitida para iniciar conversa.
- Use `/enturma talk <mensagem>` para falar com a criatura configurada mais próxima.
- Use `/enturma status` para ver o estado geral e `/enturma reload` para recarregar a configuração.
- A configuração de IDs fica em `config/enturma-mobs.json`; o menu de seleção pode ser aberto ao criar um mundo.

## Backend e Qwen

O mod chama o backend HTTP configurado em `config/enturma-common.toml` (`aiEndpoint`). A chave do Qwen deve ficar no backend, em `QWEN_API_KEY` ou `DASHSCOPE_API_KEY`, nunca no JAR. Para usar QwenCloud, configure `QWEN_MODEL=qwen3.8-max` no backend e verifique a cota da conta.

## Limites de segurança e estabilidade

As mensagens de chat não executam comandos de console. A resposta do modelo admite apenas ações tipadas como olhar, seguir com mobs não hostis, emote, som ambiente e entregar itens sob solicitação explícita. Requisições concorrentes para o mesmo mob são bloqueadas, e históricos são limitados.


## Comandos de conversa

- `/chat local <texto>`: envia o texto ao mob permitido mais próximo, dentro do raio local configurado.
- `/chat global <texto>`: envia o texto a todos os mobs permitidos, vivos e carregados dentro da distância de renderização configurada no servidor. As respostas são entregues ao jogador que executou o comando.
- `/enturma status`: exibe o estado da IA e a configuração de criaturas.
- `/enturma reload`: recarrega a lista de criaturas (requer permissão de operador).

Os comandos respeitam `config/enturma-mobs.json`: por padrão, somente aldeões, comerciantes errantes e golens de ferro são permitidos. Para adicionar outros IDs, edite o arquivo e execute `/enturma reload`. A conversa global cria uma requisição independente por criatura; o cliente HTTP usa fila assíncrona limitada para não bloquear a thread do servidor. Criaturas já ocupadas por outra conversa podem ser ignoradas e não geram uma mensagem de erro para cada mob.

O servidor controla a distância de renderização de entidades e não consegue descobrir de forma confiável a distância de renderização individual configurada no cliente. Por isso, o alcance de `/chat global` segue a distância de renderização do servidor.
