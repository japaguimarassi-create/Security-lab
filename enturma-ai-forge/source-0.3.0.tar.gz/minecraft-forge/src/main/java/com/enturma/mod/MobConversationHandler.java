package com.enturma.mod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Comparator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MobConversationHandler {
    private static final Map<UUID, UUID> ACTIVE_MOB_BY_PLAYER = new ConcurrentHashMap<>();
    private static final Map<UUID, UUID> ACTIVE_PLAYER_BY_MOB = new ConcurrentHashMap<>();
    private static final Map<UUID, java.util.List<AIClient.Turn>> MEMORY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_TALK_TICK = new ConcurrentHashMap<>();
    private static final java.util.Set<UUID> IN_FLIGHT_MOBS = ConcurrentHashMap.newKeySet();
    private static final java.util.Set<UUID> GLOBAL_CHAT_MOBS = ConcurrentHashMap.newKeySet();

    @SubscribeEvent
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide() || !EnturmaConfig.ENABLED.get()) return;
        if (!(event.getEntity() instanceof ServerPlayer player) || !(event.getTarget() instanceof Mob mob)) return;
        if (!MobSettings.allows(mob) || !player.isCrouching() || !event.getItemStack().isEmpty()) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        beginConversation(mob, player, "__greeting__");
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID playerId = event.getEntity().getUUID();
        UUID mobId = ACTIVE_MOB_BY_PLAYER.remove(playerId);
        if (mobId != null) ACTIVE_PLAYER_BY_MOB.remove(mobId, playerId);
    }

    @SubscribeEvent
    public void onEntityLeaveLevel(EntityLeaveLevelEvent event) {
        if (!(event.getEntity() instanceof Mob mob)) return;
        UUID mobId = mob.getUUID();
        MEMORY.remove(mobId);
        LAST_TALK_TICK.remove(mobId);
        IN_FLIGHT_MOBS.remove(mobId);
        GLOBAL_CHAT_MOBS.remove(mobId);
        UUID playerId = ACTIVE_PLAYER_BY_MOB.remove(mobId);
        if (playerId != null) ACTIVE_MOB_BY_PLAYER.remove(playerId, mobId);
        ACTIVE_MOB_BY_PLAYER.entrySet().removeIf(entry -> entry.getValue().equals(mobId));
    }

    @SubscribeEvent
    public void onServerChat(ServerChatEvent event) {
        if (!EnturmaConfig.ENABLED.get() || !EnturmaConfig.CHAT_CAPTURE.get()) return;
        ServerPlayer player = event.getPlayer();
        String message = event.getMessage().getString().trim();
        if (message.isEmpty() || message.startsWith("/") || message.length() > 1500) return;
        UUID mobId = ACTIVE_MOB_BY_PLAYER.get(player.getUUID());
        if (mobId == null) return;
        Mob mob = findMob(player.serverLevel(), mobId);
        if (mob == null || !mob.isAlive() || mob.distanceToSqr(player) > Math.pow(EnturmaConfig.TALK_RADIUS.get(), 2)) {
            ACTIVE_MOB_BY_PLAYER.remove(player.getUUID());
            ACTIVE_PLAYER_BY_MOB.remove(mobId);
            return;
        }
        sendTurn(mob, player, message);
    }

    public static int forceTalk(ServerPlayer player, String message) {
        if (!EnturmaConfig.ENABLED.get()) {
            player.sendSystemMessage(Component.literal("Enturma AI está desligado."));
            return 0;
        }
        message = message == null ? "" : message.strip();
        if (message.isEmpty() || message.length() > 1500) {
            player.sendSystemMessage(Component.literal("Uso: /chat local <texto> — escreva de 1 a 1500 caracteres."));
            return 0;
        }
        double radius = EnturmaConfig.TALK_RADIUS.get();
        Mob closest = player.serverLevel().getEntitiesOfClass(Mob.class,
                player.getBoundingBox().inflate(radius), mob -> mob.isAlive() && MobSettings.allows(mob))
            .stream().filter(mob -> mob.distanceToSqr(player) <= radius * radius)
            .min(Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
        if (closest == null) {
            player.sendSystemMessage(Component.literal("Nenhuma criatura configurada por perto. Agache e clique em um mob ou ajuste a lista de IDs."));
            return 0;
        }
        beginConversation(closest, player, message);
        return 1;
    }

    public static int forceGlobalTalk(ServerPlayer player, String message) {
        if (!EnturmaConfig.ENABLED.get()) {
            player.sendSystemMessage(Component.literal("Enturma AI está desligado."));
            return 0;
        }
        message = message == null ? "" : message.strip();
        if (message.isEmpty() || message.length() > 1500) {
            player.sendSystemMessage(Component.literal("Uso: /chat global <texto> — escreva de 1 a 1500 caracteres."));
            return 0;
        }
        double radius = renderRadius(player);
        java.util.List<Mob> mobs = player.serverLevel()
            .getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(radius),
                mob -> mob.isAlive() && MobSettings.allows(mob))
            .stream().filter(mob -> mob.distanceToSqr(player) <= radius * radius)
            .collect(java.util.stream.Collectors.toCollection(java.util.ArrayList::new));
        mobs.sort(Comparator.comparingDouble(player::distanceToSqr));
        if (mobs.isEmpty()) {
            player.sendSystemMessage(Component.literal("[Enturma AI] Nenhum mob configurado está na sua área de renderização."));
            return 0;
        }
        int submitted = 0;
        for (Mob mob : mobs) {
            UUID mobId = mob.getUUID();
            UUID previousPlayer = ACTIVE_PLAYER_BY_MOB.remove(mobId);
            if (previousPlayer != null) ACTIVE_MOB_BY_PLAYER.remove(previousPlayer, mobId);
            GLOBAL_CHAT_MOBS.add(mobId);
            MEMORY.computeIfAbsent(mobId, ignored -> new java.util.ArrayList<>());
            pruneMemory(mobId);
            mob.lookAt(player, 180.0F, 90.0F);
            if (sendTurn(mob, player, message, false)) submitted++;
        }
        player.sendSystemMessage(Component.literal("[Enturma AI] Mensagem global enviada a " + submitted + " de " + mobs.size() + " mobs elegíveis na área de renderização."));
        return submitted > 0 ? 1 : 0;
    }

    private static double renderRadius(ServerPlayer player) {
        int viewDistance = player.serverLevel().getServer().getPlayerList().getViewDistance();
        return Math.max(16.0D, viewDistance * 16.0D);
    }

    private static void beginConversation(Mob mob, ServerPlayer player, String message) {
        UUID playerId = player.getUUID();
        UUID mobId = mob.getUUID();
        UUID previousMob = ACTIVE_MOB_BY_PLAYER.put(playerId, mobId);
        if (previousMob != null && !previousMob.equals(mobId)) ACTIVE_PLAYER_BY_MOB.remove(previousMob, playerId);
        UUID previousPlayer = ACTIVE_PLAYER_BY_MOB.put(mobId, playerId);
        if (previousPlayer != null && !previousPlayer.equals(playerId)) ACTIVE_MOB_BY_PLAYER.remove(previousPlayer, mobId);
        MEMORY.computeIfAbsent(mobId, ignored -> new java.util.ArrayList<>());
        pruneMemory(mobId);
        mob.lookAt(player, 180.0F, 90.0F);
        sendTurn(mob, player, message);
    }

    private static void pruneMemory(UUID currentMobId) {
        if (MEMORY.size() <= 512) return;
        for (UUID candidate : MEMORY.keySet()) {
            if (!candidate.equals(currentMobId)) {
                MEMORY.remove(candidate);
                LAST_TALK_TICK.remove(candidate);
                IN_FLIGHT_MOBS.remove(candidate);
                if (MEMORY.size() <= 448) break;
            }
        }
    }

    private static Mob findMob(ServerLevel level, UUID id) {
        return level.getEntity(id) instanceof Mob mob ? mob : null;
    }

    private static boolean sendTurn(Mob mob, ServerPlayer player, String message) {
        return sendTurn(mob, player, message, true);
    }

    private static boolean sendTurn(Mob mob, ServerPlayer player, String message, boolean notifyBusy) {
        UUID mobId = mob.getUUID();
        if (!IN_FLIGHT_MOBS.add(mobId)) {
            GLOBAL_CHAT_MOBS.remove(mobId);
            if (notifyBusy) {
                player.sendSystemMessage(Component.literal("[Enturma AI] Uma criatura está ocupada; tente novamente em alguns instantes."));
            }
            return false;
        }
        long currentTick = player.serverLevel().getServer().getTickCount();
        Long previous = LAST_TALK_TICK.put(mobId, currentTick);
        if (previous != null && currentTick - previous < 2) {
            IN_FLIGHT_MOBS.remove(mobId);
            GLOBAL_CHAT_MOBS.remove(mobId);
            if (notifyBusy) {
                player.sendSystemMessage(Component.literal("[Enturma AI] Aguarde um instante antes de falar com essa criatura novamente."));
            }
            return false;
        }
        java.util.List<AIClient.Turn> memory = MEMORY.computeIfAbsent(mobId, ignored -> new java.util.ArrayList<>());
        java.util.List<AIClient.Turn> history;
        synchronized (memory) {
            memory.add(new AIClient.Turn("user", message));
            while (memory.size() > 8) memory.remove(0);
            history = java.util.List.copyOf(memory);
        }
        try {
            boolean accepted = AIClient.request(mob, player, message, history);
            if (!accepted) {
                IN_FLIGHT_MOBS.remove(mobId);
                GLOBAL_CHAT_MOBS.remove(mobId);
            }
            return accepted;
        } catch (RuntimeException exception) {
            IN_FLIGHT_MOBS.remove(mobId);
            GLOBAL_CHAT_MOBS.remove(mobId);
            player.sendSystemMessage(Component.literal("[Enturma AI] Não foi possível iniciar a requisição; tente novamente."));
            return false;
        }
    }

    public static void releaseRequest(UUID mobId) {
        IN_FLIGHT_MOBS.remove(mobId);
        GLOBAL_CHAT_MOBS.remove(mobId);
    }

    public static void acceptReply(Mob mob, ServerPlayer player, String dialogue, String emotion, com.google.gson.JsonArray actions) {
        if (!mob.isAlive() || !player.isAlive() || mob.level() != player.level()) return;
        boolean global = GLOBAL_CHAT_MOBS.contains(mob.getUUID());
        double responseRadius = global ? renderRadius(player) + 2.0D : EnturmaConfig.TALK_RADIUS.get() + 2.0D;
        if (mob.distanceToSqr(player) > responseRadius * responseRadius) return;
        if (global) GLOBAL_CHAT_MOBS.remove(mob.getUUID());
        String safeDialogue = dialogue == null ? "Não consegui formular uma resposta." : dialogue.strip();
        if (safeDialogue.isEmpty()) safeDialogue = "Não consegui formular uma resposta.";
        if (safeDialogue.length() > 600) safeDialogue = safeDialogue.substring(0, 600);
        String name = mob.getDisplayName().getString();
        Component line = Component.literal("[" + name + "] " + safeDialogue);
        if (global) {
            player.sendSystemMessage(line);
        } else {
            double radiusSqr = Math.pow(EnturmaConfig.TALK_RADIUS.get() + 2, 2);
            for (ServerPlayer nearby : player.serverLevel().players()) {
                if (nearby.distanceToSqr(mob) <= radiusSqr) nearby.sendSystemMessage(line);
            }
        }
        ActionExecutor.execute(mob, player, actions, emotion);
        VoiceBridge.speak(mob, safeDialogue);
        java.util.List<AIClient.Turn> memory = MEMORY.computeIfAbsent(mob.getUUID(), ignored -> new java.util.ArrayList<>());
        synchronized (memory) {
            memory.add(new AIClient.Turn("assistant", safeDialogue));
            while (memory.size() > 8) memory.remove(0);
        }
    }
}
